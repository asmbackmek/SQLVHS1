-- Hannah und Jan und Mirjam
-- Ü3 - Hotel "Vacanza da sogno"

CREATE DATABASE uebung3; # DB erstellen
USE uebung3; # DB auswählen

CREATE TABLE tbl_kunde
(
k_id VARCHAR(100) PRIMARY KEY,
k_vorname VARCHAR(100),
k_nachname VARCHAR(100),
k_strasse VARCHAR(100),
k_plz VARCHAR(10),
k_ort VARCHAR(100),
k_land VARCHAR(100),
k_iban VARCHAR(100),
k_email VARCHAR(100),
CONSTRAINT Check_Email CHECK (k_email LIKE "%@%")
);
SELECT * FROM tbl_kunde;

CREATE TABLE tbl_zimmer
(
z_id VARCHAR(100) PRIMARY KEY,
z_kategorie VARCHAR(100),
z_meerblick BOOLEAN,
z_qm INT,
z_preis INT
);
SELECT * FROM tbl_zimmer;

CREATE TABLE tbl_ausflug
(
a_id VARCHAR(100) PRIMARY KEY,
a_ziel VARCHAR(100),
a_std INT,
a_preis INT
);
SELECT * FROM tbl_ausflug;

CREATE TABLE tbl_mitarbeiter
(
ma_id VARCHAR(100) PRIMARY KEY,
ma_vorname VARCHAR(100),
ma_nachname VARCHAR(100)
);
SELECT * FROM tbl_mitarbeiter;

CREATE TABLE tbl_zahlweise
(
zahlung_id INT PRIMARY KEY,
zahlung_art VARCHAR(100)
);
SELECT * FROM tbl_zahlweise;

CREATE TABLE tbl_buchung
(
b_id VARCHAR(100) PRIMARY KEY,
FK_k_id VARCHAR(100),
CONSTRAINT kunde_buchung FOREIGN KEY (FK_k_id) REFERENCES tbl_kunde(k_id),
FK_ma_id VARCHAR(100),
CONSTRAINT mitarbeiter_buchung FOREIGN KEY (FK_ma_id) REFERENCES tbl_mitarbeiter(ma_id),
b_datum_start DATE,
b_datum_ende DATE,
b_persanz TINYINT,
b_hauptsaison BOOL,
b_storno BOOL,
FK_zahlung_id INT ,
CONSTRAINT zahlweise_buchung FOREIGN KEY (FK_zahlung_id) REFERENCES tbl_zahlweise(zahlung_id)
);
SELECT * FROM tbl_buchung;

CREATE TABLE tbl_buchung_zimmer
(
FK_b_id VARCHAR(100),
CONSTRAINT buchung_zimmer_buchung FOREIGN KEY (FK_b_id) REFERENCES tbl_buchung(b_id),
FK_z_id VARCHAR(100),
CONSTRAINT buchung_zimmer_zimmer FOREIGN KEY (FK_z_id) REFERENCES tbl_zimmer(z_id),
PRIMARY KEY (FK_b_id, FK_z_id)
);
SELECT * FROM tbl_buchung_zimmer;

CREATE TABLE tbl_buchung_ausflug
(
FK_b_id VARCHAR(100),
CONSTRAINT buchung_ausflug_buchung FOREIGN KEY (FK_b_id) REFERENCES tbl_buchung(b_id),
FK_a_id VARCHAR(100),
CONSTRAINT buchung_ausflug_ausflug FOREIGN KEY (FK_a_id) REFERENCES tbl_ausflug(a_id),
PRIMARY KEY (FK_b_id, FK_a_id)
);
SELECT * FROM tbl_buchung_ausflug;

SHOW TABLES;


INSERT INTO tbl_zimmer VALUE (1, 'standard', 1, 20, 60), (2, 'deluxe', 1, 60, 200);
INSERT INTO tbl_ausflug VALUE (1, 'rom', 6, 100), (2, 'meer', 10, 70);
INSERT INTO tbl_kunde VALUE (1, 'Horst', 'Mülller', 'Strasse 5', '90490', 'Ort', 'DE', 'fakeiban', 'fake@email.com'), (2, 'Horst2', 'Mülller2', 'Strasse 55', '904500', 'Ort2', 'DE', 'fakeiban2', 'fake2@email.com');
INSERT INTO tbl_kunde VALUE (3, 'Maria', 'macher', 'Strasse 199', '90222', 'Ort3', 'DE', 'fakeiban3', 'fake3@email.com');
INSERT INTO tbl_mitarbeiter VALUE (1, 'Giovanni', 'Ippolito'), (2, 'Emmanuel', 'Medici'), (3, 'Davide', 'Ferrari');
INSERT INTO tbl_zahlweise VALUE (1, 'Bar'), (2, 'Kreditkarte VISA'), (3, 'Kreditkarte MASTER'), (4, 'EC-Karte');
#INSERT INTO tbl_buchung (b_id, FK_ma_id, FK_k_id) VALUE (1, 2, 1), (2, 3, 1), (3, 1, 1), (4, 1, 2);
INSERT INTO tbl_buchung VALUE (1, 2, 1, '2020-01-15', '2020-01-20', 3, 0, 0, 2), (2, 3, 1, '2021-06-15', '2021-07-25', 3, 1, 1, 3), (3, 1, 2, '2021-10-05', '2021-10-10', 2, 0, 1, 3);
INSERT INTO tbl_buchung VALUE (4, 1, 2, '2022-07-01', '2021-07-15', 2, 1, 1, 4), (5, 2, 3, '2022-08-01', '2021-08-07', 1, 0, 1, 1);
INSERT INTO tbl_buchung_zimmer VALUE (1, 1), (1, 2), (2, 1), (3, 2), (4, 2), (5, 1);
INSERT INTO tbl_buchung_ausflug VALUE (1, 1), (3, 2), (3, 1), (4, 2);
SELECT * FROM tbl_buchung;
SELECT * FROM tbl_kunde;
SELECT * FROM tbl_ausflug;
SELECT * FROM tbl_buchung_ausflug;
SELECT * FROM tbl_zahlweise;

# Datumseingabe: '2020-01-15'

# Auswertungen zb der Zimmer mit joints, views etc


CREATE VIEW v_mitarbeiter_buchung AS
SELECT ma_nachname, bu.b_id
FROM tbl_mitarbeiter INNER JOIN tbl_buchung bu
ON ma_id = bu.FK_ma_id
ORDER BY ma_nachname;
SELECT * FROM v_mitarbeiter_buchung;


CREATE VIEW v_mitarbeiter_buchung2 AS
SELECT ma_nachname, b_id
FROM tbl_mitarbeiter INNER JOIN tbl_buchung
ON ma_id = FK_ma_id
ORDER BY ma_nachname;
SELECT * FROM v_mitarbeiter_buchung2;


SELECT ma_nachname, COUNT(b_id) AS Buchungsanzahl FROM v_mitarbeiter_buchung2
GROUP BY ma_nachname;

/*
CREATE VIEW v_mitarbeiter_buchung3 AS
SELECT ma_nachname, ma_vorname, b_id
FROM tbl_mitarbeiter INNER JOIN tbl_buchung
ON ma_id = FK_ma_id
ORDER BY ma_nachname;
SELECT * FROM v_mitarbeiter_buchung3;

SELECT ma_nachname, ma_vorname, COUNT(b_id) AS Buchungsanzahl FROM v_mitarbeiter_buchung3
GROUP BY ma_nachname, ma_vorname;
*/

# Ziel: Join buchung - buchung_zimmer - zimmer, für alle Buchungen daher LEFT JOIN
CREATE VIEW v_buchung_zimmer AS
SELECT b.*, z.*, bz.*
FROM tbl_buchung b LEFT JOIN tbl_buchung_zimmer bz
ON b.b_id = bz.FK_b_id
LEFT JOIN tbl_zimmer z
ON bz.FK_z_id = z.z_id
;
SELECT * FROM v_buchung_zimmer;
#DROP VIEW v_buchung_zimmer;

SELECT (datediff(b_datum_ende, b_datum_start)) AS b_dauerintage, b_id, b_datum_ende, b_datum_start
FROM v_buchung_zimmer;

SELECT b_id, b_datum_ende, b_datum_start, z_preis, (datediff(b_datum_ende, b_datum_start)) AS b_dauerintage, (datediff(b_datum_ende, b_datum_start)*z_preis) AS b_preisgesamt
FROM v_buchung_zimmer;

SELECT b_id, b_datum_ende, b_datum_start, z_preis, @ b_dauerintage:=datediff(b_datum_ende, b_datum_start), (datediff(b_datum_ende, b_datum_start)*z_preis) AS b_preisgesamt
FROM v_buchung_zimmer;


# FRAGE: wie kann ich auf den Alias b_dauerintage in der Formel für Gesamtpreis verweisen?
SELECT
    b_id,
    b_datum_ende,
    b_datum_start,
    z_preis,
    @b_dauerintage := DATEDIFF(b_datum_ende, b_datum_start) , # @variablename
    (@b_dauerintage * z_preis) AS b_preisgesamt
FROM
    v_buchung_zimmer;
# dynamische Spalte in Tabelle Buchung erstellen
ALTER TABLE tbl_buchung
ADD COLUMN b_dauerintage INT AS (datediff(b_datum_ende, b_datum_start));
SELECT * FROM tbl_buchung;

/*
# Frage: wie kann ich den gesamtpreis als dynamische Spalte in Buchung integrieren?
ALTER TABLE tbl_buchung
ADD COLUMN b_preisgesamt INT AS ((datediff(b_datum_ende, b_datum_start)*tbl_zimmer.z_preis));
SELECT * FROM tbl_buchung;
*/





/*
ALTER TABLE tbl_buchung
ADD COLUMN b_preisgesamt INT AS (DATEDIFF(b_datum_ende, b_datum_start) *(SELECT  z_preis FROM uebung3.v_buchung_zimmer  ) )  ;






#########################

                                
							
SELECT z_preis FROM tbl_zimmer WHERE zimmer_id = tbl_buchung.z_id;
SELECT * FROM tbl_buchung;
/*
SELECT b_id, b_datum_ende, b_datum_start, z_preis, b_hauptsaison, (datediff(b_datum_ende, b_datum_start)) AS b_dauerintage, (datediff(b_datum_ende, b_datum_start)*z_preis) AS b_preisgesamt
IF b_hauptsaison = 1 THEN
b_preisgesamt = b_preisgesamt*2
ELSE b_preisgesamt = b_preisgesamt
END IF
FROM v_buchung_zimmer;
# neue Spalte erstellen oder UPDATE machen
*/
SELECT
    b_id,
    b_datum_ende,
    b_datum_start,
    z_preis,
    b_hauptsaison,
    DATEDIFF(b_datum_ende, b_datum_start) AS b_dauerintage,
    CASE WHEN b_hauptsaison = 1 THEN (DATEDIFF(b_datum_ende, b_datum_start) * z_preis * 2)
         ELSE (DATEDIFF(b_datum_ende, b_datum_start) * z_preis)
    END AS b_preisgesamt
FROM
    v_buchung_zimmer;

UPDATE tbl_buchung
SET b_datum_ende = '2022-07-15'
WHERE b_id = '4'; # Korrektur

UPDATE tbl_buchung
SET b_datum_ende = '2022-08-07'
WHERE b_id = '5'; # Korrektur



/*
Asmae Feedback: 
- zahlungsweise könnte in extra Tabelle ausgelagert werden mit FK in buchung --> done
- Ort, plz, Land könnte in extra Tabelle ausgelagert werden mit FK in kunde
- welcher Mitarbeiter hat Buchung bearbeitet? extra Entität für Mitarbeiter einführen --> done
*/


#DROP DATABASE uebung3;

/* V1
CREATE TABLE tbl_buchung
(
b_id VARCHAR(100) PRIMARY KEY,
FK_k_id VARCHAR(100),
CONSTRAINT kunde_buchung FOREIGN KEY (FK_k_id) REFERENCES tbl_kunde(k_id),
FK_z_id VARCHAR(100),
CONSTRAINT zimmer_buchung FOREIGN KEY (FK_z_id) REFERENCES tbl_zimmer(z_id),
FK_a_id VARCHAR(100),
CONSTRAINT ausflug_buchung FOREIGN KEY (FK_a_id) REFERENCES tbl_ausflug(a_id),
b_datum_start DATE,
b_datum_ende DATE,
b_persanz TINYINT,
b_preis INT,
b_storno BOOL,
b_zahlweise VARCHAR(100)
);
*/

/* V2
CREATE TABLE tbl_buchung_zimmer
(
FK_b_id VARCHAR(100),
CONSTRAINT buchung_zimmer_buchung FOREIGN KEY (FK_b_id) REFERENCES tbl_buchung(b_id),
FK_z_id VARCHAR(100),
CONSTRAINT buchung_zimmer_zimmer FOREIGN KEY (FK_z_id) REFERENCES tbl_zimmer(z_id),
PRIMARY KEY (FK_b_id, FK_z_id)
);
SELECT * FROM tbl_buchung_zimmer;
#Error Code: 1824. Failed to open the referenced table 'tbl_buchung'

CREATE TABLE tbl_buchung_ausflug
(
FK_b_id VARCHAR(100),
CONSTRAINT buchung_ausflug_buchung FOREIGN KEY (FK_b_id) REFERENCES tbl_buchung(b_id),
FK_a_id VARCHAR(100),
CONSTRAINT buchung_ausflug_ausflug FOREIGN KEY (FK_a_id) REFERENCES tbl_ausflug(a_id),
PRIMARY KEY (FK_b_id, FK_a_id)
);
SELECT * FROM tbl_buchung_ausflug;


CREATE TABLE tbl_buchung
(
b_id VARCHAR(100) PRIMARY KEY,
FK_k_id VARCHAR(100),
CONSTRAINT kunde_buchung FOREIGN KEY (FK_k_id) REFERENCES tbl_kunde(k_id),
FK_bz_id VARCHAR(100),
CONSTRAINT buchung_buchung_zimmer FOREIGN KEY (FK_bz_id) REFERENCES tbl_buchung_zimmer(FK_z_id, FK_b_id),
FK_ba_id VARCHAR(100),
CONSTRAINT buchung_buchung_ausflug FOREIGN KEY (FK_ba_id) REFERENCES tbl_buchung_ausflug(FK_a_id, FK_b_id),
b_datum_start DATE,
b_datum_ende DATE,
b_persanz TINYINT,
b_preis INT,
b_storno BOOL,
b_zahlweise VARCHAR(100)
);
SELECT * FROM tbl_buchung;
*/