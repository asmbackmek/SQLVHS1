-- ich bin eine Kommentar
# ich bin auvh ein Kommentar

/*
Hier kannst Du mehrere Zeilen Komentar schribe
In diesem Sript werden wir die folgenden Themen besprechen:
* 1- Create Database
* 2- Drop Database
* 3- Use Database
*/

-- Datenbank (DB) erstellen
CREATE DATABASE my_test_db;
CREATE DATABASE aa_test_db;
CREATE DATABASE aa_test_db1;

-- DB auswählen
USE my_test_db; -- DB auswählen



-- DB Löschen
DROP DATABASE aa_test_db1;
DROP DATABASE aa_test_db;
